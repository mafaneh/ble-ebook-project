
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'saadc_pca10036' 
 * Target:  'nrf52832_xxaa' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


#endif /* RTE_COMPONENTS_H */
